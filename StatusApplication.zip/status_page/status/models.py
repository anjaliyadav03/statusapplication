from django.db import models

def get_status_choices():  # Define the choices function *FIRST*
    return [
        ('operational', 'Operational'),
        ('degraded', 'Degraded'),
        ('down', 'Down'),
        ('maintenance', 'Under Maintenance'),
    ]

def get_default_service():  # Define the default service function
    try:
        return Service.objects.get(name="Your Default Service Name")  # Replace with your criteria
    except Service.DoesNotExist:
        # Handle the case where the default service doesn't exist.
        # You could create it here or return None (and then handle NULLs later)
        return None


class Service(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name

class ServiceStatus(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='statuses', default=get_default_service, null=True, blank=True)  # Default using callable
    status = models.CharField(
        max_length=20,
        choices=get_status_choices,  # Use the callable here
        default='operational',
    )
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.service.name}: {self.status}"


class ServiceStatusHistory(models.Model):
    service_status = models.ForeignKey(ServiceStatus, on_delete=models.CASCADE, related_name='history')
    old_status = models.CharField(max_length=20, choices=get_status_choices)  # Use the callable here
    new_status = models.CharField(max_length=20, choices=get_status_choices)  # Use the callable here
    updated_at = models.DateTimeField(auto_now_add=True)  # Corrected typo (auto_now_add)

    def __str__(self):
        return f"{self.service_status.service.name}: {self.old_status} -> {self.new_status}"