from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail

from status_page.settings import DEFAULT_FROM_EMAIL
from .models import ServiceStatus

@receiver(post_save, sender=ServiceStatus)
def send_status_change_email(sender, instance, created, **kwargs):
    if not created:  # Only send email if status was updated
        try:
            old_status = ServiceStatus.objects.get(pk=instance.pk).status # Get the status from the database
            if old_status != instance.status:
                send_mail(
                    f'Service Status Changed: {instance.service.name}',
                    f'The status of {instance.service.name} has changed from {old_status} to {instance.status}.',
                    DEFAULT_FROM_EMAIL,  # Your from email
                    ['mishraabhijeet2001@gmail.com'],  # Recipient email(s)
                    fail_silently=True,  # Handle email sending errors gracefully
                )
        except ServiceStatus.DoesNotExist:
            pass # Object doesn't exist, probably a delete