from rest_framework import serializers
from .models import ServiceStatus

class ServiceStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceStatus
        fields = ('service', 'status', 'updated_at') # Choose the fields you want to expose